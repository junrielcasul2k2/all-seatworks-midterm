namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        private Form2 form;
        public Form1()
        {
            InitializeComponent();
            form = new Form2();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] inputValues = textBox1.Text.Split(' ');
            int[] num = new int[2];

            if (inputValues.Length >= 2)
            {
                num[0] = Convert.ToInt32(inputValues[0]);
                num[1] = Convert.ToInt32(inputValues[1]);
            }
            else
            {
                MessageBox.Show("Please enter two numbers separated by a space.");
            }

            
            form.display(num);
            this.Hide();
            form.Show();
            

        }
    }
}
