namespace WinFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }


        public void display(int[] number)
        {
            int temp = number[0];
            number[0] = number[1];
            number[1] = temp;
            label1.Text = $"Arranged numbers: {number[0]}, {number[1]}";
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
