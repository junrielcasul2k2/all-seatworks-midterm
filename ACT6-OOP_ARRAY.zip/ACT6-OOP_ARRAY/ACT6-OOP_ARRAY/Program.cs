﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACT6_OOP_ARRAY
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("                    WELCOME!");
            Console.WriteLine("---------------------------------------------------");


            Console.Write("How many names you want to enter: ");
            int indexCount = int.Parse(Console.ReadLine());

            WorkExperience[] NP = new WorkExperience[indexCount];
            NP = getInput(NP, indexCount);

            int choice;
            do
            {
                Console.WriteLine("");
                Console.WriteLine("OPTION:");
                Console.WriteLine("1. FIND INDEX");
                Console.WriteLine("2. SORT ASCENDING");
                Console.WriteLine("3. SORT DESCENDING");
                Console.WriteLine("4. REVERSED THE NAMES");
                Console.WriteLine("5. LENGTH OF ALL NAMES");
                Console.WriteLine("6. DISPLAY ALL DATA");
                Console.WriteLine("0. EXIT");

                Console.WriteLine("");

                Console.Write("Enter Choice: ");
                choice = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("");
                switch (choice)
                {
                    case 1:
                        getIndex(NP);
                        break;

                    case 2:
                        Console.WriteLine("SORTED ASCENDING: ");
                        NP = sortAsc(NP);
                        display(NP);
                        break;
                    case 3:
                        Console.WriteLine("SORT DESCENDING: ");
                        NP = sortDesc(NP);
                        display(NP);
                        break;
                    case 4:
                        Console.WriteLine("REVERSED ALL NAMES: ");
                        NP = reverse(NP);
                        display(NP);
                        break;
                    case 5:
                        Length(NP);
                        break;
                    case 6:
                        Console.WriteLine("ALL DATA: ");
                        display(NP);
                        break;
                }
            } while (choice != 0);


        }

        //METHODS to ask for Inputs
        static WorkExperience[] getInput(WorkExperience[] WE, int indexCount)
        {
            for (int i = 0; i < indexCount; i++)
            {
                Console.WriteLine("");
                Console.WriteLine($"Student in Index [{i}]");
                Console.Write("First Name : ");
                string firstname = Console.ReadLine();
                Console.Write("Last Name : ");
                string lastname = Console.ReadLine();
                Console.Write("Age: ");
                int age = int.Parse(Console.ReadLine());


                Console.Write("Course Description: ");
                string coursedesc = Console.ReadLine();
                Console.Write("Year Level: ");
                int yearlevel = int.Parse(Console.ReadLine());


                Console.Write("Work Description: ");
                string workdesc = Console.ReadLine();
                Console.Write("No. Of Experience: ");
                int noofexperience = int.Parse(Console.ReadLine());



                WE[i] = new WorkExperience(firstname, lastname, age, coursedesc, yearlevel, workdesc, noofexperience);
            }
            return WE;
        }
        //METHODS to search the Index of the Name
        static void getIndex(WorkExperience[] WE)
        {
            Console.Write("Enter Full Name to search its index: ");
            string fullName = Console.ReadLine();
            bool found = false;
            int foundIndex = -1;
            for (int i = 0; i < WE.Length; i++)
            {
                if (fullName == WE[i].getFirstName() + " " + WE[i].getLastName())
                {
                    found = true;
                    foundIndex = i;
                    break;
                }
            }
            if (found == true)
            {
                Console.WriteLine($"The name is found at index {foundIndex}");
            }
            else
            {
                Console.WriteLine("The name is not found");
            }
        }
        // METHODS to Sort Names in Ascending Order
        static WorkExperience[] sortAsc(WorkExperience[] WE)
        {
            for (int i = 0; i < WE.Length - 1; i++)
            {
                for (int j = 0; j < WE.Length - i - 1; j++)
                {
                    if (WE[j].getLastName().CompareTo(WE[j + 1].getLastName()) > 0)
                    {

                        WorkExperience temp = WE[j];
                        WE[j] = WE[j + 1];
                        WE[j + 1] = temp;
                    }
                }
            }
            return WE;
        }

        // METHODS to Sort Names in Descending Order
        static WorkExperience[] sortDesc(WorkExperience[] WE)
        {
            for (int i = 0; i < WE.Length - 1; i++)
            {
                for (int j = 0; j < WE.Length - i - 1; j++)
                {
                    if (WE[j].getLastName().CompareTo(WE[j + 1].getLastName()) < 0)
                    {

                        WorkExperience temp = WE[j];
                        WE[j] = WE[j + 1];
                        WE[j + 1] = temp;
                    }
                }
            }
            return WE;
        }

        //METHOD to Reversed names
        static WorkExperience[] reverse(WorkExperience[] WE)
        {
            WorkExperience[] reversed = new WorkExperience[WE.Length];
            for (int i = 0; i < WE.Length; i++)
            {
                string tempFirstName = WE[i].getFirstName();
                string tempLastName = WE[i].getLastName();
                string reversedFirstName = "";
                string reversedLastName = "";

                for (int u = tempFirstName.Length - 1; u >= 0; u--)
                {
                    reversedFirstName += tempFirstName[u];
                }

                for (int z = tempLastName.Length - 1; z >= 0; z--)
                {
                    reversedLastName += tempLastName[z];
                }

                reversed[i] = new WorkExperience(reversedFirstName, reversedLastName, WE[i].getAge(), WE[i].getCourseDesc(),
                               WE[i].getYearLevel(), WE[i].getWorkDesc(), WE[i].getNoOfExperience());
            }
            return reversed;
        }

        //METHOD to Count the Length
        static void Length(WorkExperience[] WE)
        {
            for (int i = 0; i < WE.Length; i++)
            {
                int length;
                string temp;
                temp = WE[i].getFirstName() + " " + WE[i].getLastName();
                length = temp.Length;
                WE[i].displayinfo();
                Console.WriteLine("Length of Name is " + length);

            }
        }

        // METHOD to Display all Info
        static void display(WorkExperience[] WE)
        {
            for (int i = 0; i < WE.Length; i++)
            {
                Console.WriteLine($"Info in Index No.{i}");
                WE[i].displayinfo();
                Console.WriteLine();
            }
        
    
        }
    }
}
