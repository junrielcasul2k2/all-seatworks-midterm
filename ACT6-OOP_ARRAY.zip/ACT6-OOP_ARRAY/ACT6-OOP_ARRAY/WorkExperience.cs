﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACT6_OOP_ARRAY
{
    internal class WorkExperience : Course
    {
        private string workdecs;
        private int noofexperience;

        public WorkExperience(string firstname, string lastname, int age, string coursedesc, int yearlevel, string workdecs, int noofexperience)
                                : base(firstname, lastname, age, coursedesc, yearlevel)
        {
            this.workdecs = workdecs;
            this.noofexperience = noofexperience;
        }


        public string getWorkDesc()
        {
            return this.workdecs;
        }

        public int getNoOfExperience()
        {
            return this.noofexperience;
        }

        public override void displayinfo()
        {
            base.displayinfo();
            Console.WriteLine($"Work Experience: {getWorkDesc()}");
            Console.WriteLine($"No. of Experience: {getNoOfExperience()}");
            Console.WriteLine("");
        }
    }
}
