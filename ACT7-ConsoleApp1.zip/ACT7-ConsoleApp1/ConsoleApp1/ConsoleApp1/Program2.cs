﻿public class Program2
{
   public static void Main(string[] args)
    {
        Program.display();
    }
}
