﻿public class Program
{
    public static void display()
    {
        double[] scores = new double[3];
        string name;

        for (int i = 0; i < scores.Length; i++)
        {
            Console.Write($"Enter name {i + 1}: ");
            name = Console.ReadLine();

            Console.WriteLine("Scores: ");
            for (int j = 0; j < 3; j++)
            {
                scores[j] = Convert.ToDouble(Console.ReadLine());
            }
            Calculate(scores);
            Console.WriteLine("");
        }     
    }

    public static void Calculate(double[] scores)
    {
        double sum = 0;

        for (int i = 0; i < scores.Length; i++)
        {
            sum += scores[i];
        }

        double average = sum / scores.Length;

        Console.WriteLine($"The average is {average.ToString("0.00")}");
        Console.WriteLine($"The sum is {sum}");
        
    }
}
