﻿namespace TestingArraysMin_Windows
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            InputTextBox = new TextBox();
            CalculateButton = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Stencil Std", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ControlLightLight;
            label1.Location = new Point(90, 167);
            label1.Name = "label1";
            label1.Size = new Size(208, 26);
            label1.TabIndex = 0;
            label1.Text = "Enter numbers: ";
            // 
            // InputTextBox
            // 
            InputTextBox.Font = new Font("Stencil", 12F);
            InputTextBox.Location = new Point(304, 81);
            InputTextBox.Margin = new Padding(3, 4, 3, 4);
            InputTextBox.Multiline = true;
            InputTextBox.Name = "InputTextBox";
            InputTextBox.Size = new Size(63, 219);
            InputTextBox.TabIndex = 1;
            // 
            // CalculateButton
            // 
            CalculateButton.Font = new Font("Stencil", 12F);
            CalculateButton.Location = new Point(217, 351);
            CalculateButton.Margin = new Padding(3, 4, 3, 4);
            CalculateButton.Name = "CalculateButton";
            CalculateButton.Size = new Size(238, 71);
            CalculateButton.TabIndex = 2;
            CalculateButton.Text = "CALCULATE";
            CalculateButton.UseVisualStyleBackColor = true;
            CalculateButton.Click += CalculateButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlDark;
            ClientSize = new Size(653, 537);
            Controls.Add(CalculateButton);
            Controls.Add(InputTextBox);
            Controls.Add(label1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox InputTextBox;
        private Button CalculateButton;
    }
}
