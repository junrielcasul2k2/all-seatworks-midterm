namespace TestingArraysMin_Windows
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            string inputText = InputTextBox.Text;
            string[] inputNumbers = inputText.Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);

            if (!ValidateInput(inputNumbers))
                return;

            int[] numbers = ParseInput(inputNumbers);

            int min = FindMinimum(numbers);
            int count = CountOccurrences(numbers, min);

            string output = GenerateOutput(numbers, min, count);

            ShowResult(output);
        }

        private bool ValidateInput(string[] inputNumbers)
        {
            if (inputNumbers.Length != 6)
            {
                MessageBox.Show("Please enter exactly 6 numbers separated by new lines.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            foreach (string number in inputNumbers)
            {
                if (!int.TryParse(number, out _))
                {
                    MessageBox.Show("Invalid input. Please enter valid integers.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            }

            return true;
        }

        private int[] ParseInput(string[] inputNumbers)
        {
            int[] numbers = new int[6];
            for (int i = 0; i < 6; i++)
            {
                numbers[i] = int.Parse(inputNumbers[i]);
            }
            return numbers;
        }

        private int FindMinimum(int[] numbers)
        {
            int min = numbers[0];
            foreach (int num in numbers)
            {
                if (num < min)
                    min = num;
            }
            return min;
        }

        private int CountOccurrences(int[] numbers, int min)
        {
            int count = 0;
            foreach (int num in numbers)
            {
                if (num == min)
                    count++;
            }
            return count;
        }

        private string GenerateOutput(int[] numbers, int min, int count)
        {
            string output = $"The array is {string.Join(", ", numbers)}\n";
            output += $"The smallest number is {min}\n";
            output += $"The occurrence count of the smallest number is {count}";
            return output;
        }

        private void ShowResult(string output)
        {
            Form2 resultForm = new Form2(output);
            this.Hide();
            resultForm.ShowDialog();
        }
    }
}
